-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: fdb34.awardspace.net    Database: 4040510_database
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Artists`
--

DROP TABLE IF EXISTS `Artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Artists` (
  `ArtistID` int(11) NOT NULL,
  `ArtistName` varchar(50) NOT NULL,
  `City` varchar(25) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `WebAddress` varchar(40) DEFAULT NULL,
  `EntryDate` date DEFAULT NULL,
  `LeadSource` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ArtistID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Artists`
--

LOCK TABLES `Artists` WRITE;
/*!40000 ALTER TABLE `Artists` DISABLE KEYS */;
INSERT INTO `Artists` VALUES (1,'The Neurotics','Peterson','NC','USA','www.theneurotics.com','2003-05-14','Directmail'),(2,'Louis Holiday','Clinton','IL','USA',NULL,'2003-06-03','Directmail'),(3,'Word','Anderson','IN','USA',NULL,'2003-06-08','Email'),(5,'Sonata','Alexandria','VA','USA','www.classical.com/sonata','2003-06-08','Ad'),(10,'The Bullets','Alverez','TX','USA',NULL,'2003-08-10','Email'),(14,'Jose MacArthur','Santa Rosa','CA','USA','www.josemacarthur.com','2003-08-17','Ad'),(15,'Confused','Tybee Island','GA','USA',NULL,'2003-09-14','Directmail'),(17,'The Kicks','New Rochelle','NY','USA',NULL,'2003-12-03','Ad'),(16,'Today','London','ONT','Canada','www.today.com','2003-10-07','Email'),(18,'21 West Elm','Alamaba','VT','USA','www.21westelm.com','2003-02-05','Ad'),(11,'Highlander','Columbus','OH','USA',NULL,'2002-08-10','Email');
/*!40000 ALTER TABLE `Artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `AudioFile`
--

DROP TABLE IF EXISTS `AudioFile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `AudioFile` (
  `TitleID` int(11) NOT NULL,
  `Tracknum` int(11) NOT NULL,
  `AudioFormat` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `AudioFile`
--

LOCK TABLES `AudioFile` WRITE;
/*!40000 ALTER TABLE `AudioFile` DISABLE KEYS */;
INSERT INTO `AudioFile` VALUES (3,1,'MP3Format'),(1,1,'MP3Format'),(1,2,'MP3Format'),(1,3,'MP3Format'),(1,4,'MP3Format'),(1,5,'MP3Format'),(1,6,'MP3Format'),(1,7,'MP3Format'),(1,8,'MP3Format'),(3,2,'MP3Format'),(3,3,'MP3Format'),(3,4,'MP3Format'),(3,5,'MP3Format'),(3,6,'MP3Format'),(6,1,'MP3Format'),(6,2,'MP3Format'),(6,3,'MP3Format'),(6,4,'MP3Format'),(6,5,'MP3Format'),(5,1,'MP3Format'),(5,2,'MP3Format'),(5,3,'MP3Format'),(5,4,'MP3Format'),(5,5,'MP3Format'),(5,6,'MP3Format'),(5,7,'MP3Format'),(5,8,'MP3Format'),(5,9,'MP3Format'),(7,1,'MP3Format'),(7,2,'MP3Format'),(7,3,'MP3Format'),(7,4,'MP3Format'),(7,5,'MP3Format'),(7,6,'MP3Format'),(7,7,'MP3Format'),(7,8,'MP3Format');
/*!40000 ALTER TABLE `AudioFile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Building`
--

DROP TABLE IF EXISTS `Building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Building` (
  `StoreID` int(11) NOT NULL AUTO_INCREMENT,
  `Address` varchar(30) NOT NULL,
  `Name` varchar(30) NOT NULL,
  PRIMARY KEY (`StoreID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Building`
--

LOCK TABLES `Building` WRITE;
/*!40000 ALTER TABLE `Building` DISABLE KEYS */;
/*!40000 ALTER TABLE `Building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Customer` (
  `CustomerID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Birthday` date NOT NULL,
  PRIMARY KEY (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Customer`
--

LOCK TABLES `Customer` WRITE;
/*!40000 ALTER TABLE `Customer` DISABLE KEYS */;
INSERT INTO `Customer` VALUES (3,'Dale Heart','2003-05-20'),(4,'Melinda Hart','1999-04-08');
/*!40000 ALTER TABLE `Customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genre`
--

DROP TABLE IF EXISTS `Genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Genre` (
  `Genre` varchar(15) NOT NULL,
  PRIMARY KEY (`Genre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genre`
--

LOCK TABLES `Genre` WRITE;
/*!40000 ALTER TABLE `Genre` DISABLE KEYS */;
INSERT INTO `Genre` VALUES ('alternative'),('classical'),('jazz'),('metal'),('pop'),('R&B'),('rap');
/*!40000 ALTER TABLE `Genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Members`
--

DROP TABLE IF EXISTS `Members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Members` (
  `MemberID` int(11) NOT NULL,
  `FirstName` varchar(25) DEFAULT NULL,
  `LastName` varchar(25) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(25) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `HomePhone` varchar(16) DEFAULT NULL,
  `WorkPhone` varchar(16) DEFAULT NULL,
  `EMail` varchar(40) DEFAULT NULL,
  `Gender` char(1) DEFAULT NULL,
  `Birthday` date DEFAULT NULL,
  `SalesID` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`MemberID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Members`
--

LOCK TABLES `Members` WRITE;
/*!40000 ALTER TABLE `Members` DISABLE KEYS */;
INSERT INTO `Members` VALUES (10,'Roberto','Alvarez','Rt 1','Anderson','IN','46019','USA','7651552983','7651628837','ral@mightyhostl.com','M','1968-01-18',2),(31,'Jose','MacArthur','51444 Vine','Santa Rosa','CA','99999','USA','6331289393','Null','jmac@dowop.com','M','1978-06-24',1),(13,'Mary','Chrisman','1772 East 117th','Fishers','IN','46123','USA','3171820387','Null','mjc17@daviscorp.com','F','1973-03-01',1),(15,'Warren','Boyer','167 Alamo Dr','Alverez','TX','75601','USA','8221722883','Null','wbman@uptime.net','M','1969-04-19',2),(32,'Doug','Finney','2020 Dubois','Savannah','GA','30003','USA','9821222929','Null','fennyd@bitspeed.com','M','1963-08-04',3),(19,'Terry','Irving','18a 7th St','Tybee Island','GA','30004','USA','5411252093','Null','Null','M','1959-06-22',3),(21,'Michelle','Henderson','201 Bonaventure','Savannah','GA','30005','USA','8221928273','Null','Null','F','1964-03-15',2),(34,'William','Morrow','PO Box 1882','New Rochelle','NY','10014','USA','9981722928','Null','wmorrow@wmorrow.com','M','1965-03-17',2),(29,'Frank','Payne','5412 Clinton','New Rochelle','NY','10014','USA','9981737464','9981737464','Null','M','1960-01-17',1),(35,'Aiden','Franks','167 East 38th','Alverez','TX','75601','USA','8321729283','8321723833','kosmo@ispl.com','M','1983-09-02',2),(3,'Bryce','Sanders','PO Box 1292','Peterson','NC','27104','USA','6441824283','Null','bs@cookery.com','M','1966-06-11',2),(14,'Carol','Wanner','787 Airport Rd','Alverez','TX','75601','USA','6831223944','Null','Null','F','1978-11-08',3),(33,'Brian','Ranier','23 Gregory Lane','London','ONT','M6Y 2Y7 ','Canada','6231842933','Null','Null','M','1957-10-19',3),(7,'Marcellin','Lambert','142 Sample Rd','Alexandria','VA','20102','USA','8331929302','Null','mlambert@corkscrew.com','M','1959-11-14',3),(8,'Caroline','Kale','1515 Stone Church Rd','Allen','VA','20321','USA','7321223742','Null','Null','F','1956-05-30',3),(9,'Kerry','Fernandez','15 Midway','Lynchberg','VA','21223','USA','2211229384','2211223939','Null','M','1962-01-16',1),(26,'Tony','Wong','115 Maple St','McKensie','ONT','M8H 3T1','Canada','3311692832','3311692822','twong@tamilla.org','M','1955-11-01',2),(18,'Bonnie','Taft','RR4','Alamaba','VT','05303','USA','3721223292','Null','taffygirl@signon.com','F','1960-09-21',1),(20,'Louis','Holiday','15 Davis Ct','Clinton','IL','63882','USA','1451223838','Null','Null','M','1969-07-27',2),(22,'Bobby','Crum','RR2','Pine','VT','05412','USA','1831828211','Null','Null','M','1965-06-10',3),(28,'Vic','Cleaver','100 Maple','Reston','VT','05544','USA','8111839292','Null','Null','M','1957-02-10',2),(30,'Roberto','Goe','14 Gray Rd','Columbus','OH','48110','USA','2771123943','Null','Null','M','1967-09-12',1),(36,'Davis','Goodman','2020 Country Rd','Columbus','OH','48318','USA','2771152882','2771128833','goody@irvingnet.com','M','1980-10-27',2);
/*!40000 ALTER TABLE `Members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Repair`
--

DROP TABLE IF EXISTS `Repair`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Repair` (
  `WorkerID` int(11) NOT NULL,
  `VehicleID` int(11) NOT NULL,
  `Part` varchar(30) NOT NULL,
  PRIMARY KEY (`WorkerID`,`VehicleID`),
  KEY `VehicleID` (`VehicleID`),
  CONSTRAINT `Repair_ibfk_1` FOREIGN KEY (`WorkerID`) REFERENCES `Worker` (`WorkerID`),
  CONSTRAINT `Repair_ibfk_2` FOREIGN KEY (`VehicleID`) REFERENCES `Vehicle` (`VehicleID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Repair`
--

LOCK TABLES `Repair` WRITE;
/*!40000 ALTER TABLE `Repair` DISABLE KEYS */;
INSERT INTO `Repair` VALUES (1,2,'Muffler');
/*!40000 ALTER TABLE `Repair` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `SalesPeople`
--

DROP TABLE IF EXISTS `SalesPeople`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `SalesPeople` (
  `SalesID` smallint(6) NOT NULL,
  `FirstName` varchar(20) NOT NULL,
  `LastName` varchar(20) NOT NULL,
  `Initials` varchar(3) DEFAULT NULL,
  `Base` decimal(5,2) DEFAULT NULL,
  `Supervisor` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`SalesID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `SalesPeople`
--

LOCK TABLES `SalesPeople` WRITE;
/*!40000 ALTER TABLE `SalesPeople` DISABLE KEYS */;
INSERT INTO `SalesPeople` VALUES (1,'Bob','Bentley','bbb',100.00,4),(2,'Lisa','Williams','lmw',300.00,4),(3,'Clint','Sanchez','cls',100.00,1),(4,'Scott','Bull','sjb',NULL,NULL);
/*!40000 ALTER TABLE `SalesPeople` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Student`
--

DROP TABLE IF EXISTS `Student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Student` (
  `STU_ID` int(11) NOT NULL,
  `STU_FNAME` varchar(20) DEFAULT NULL,
  `STU_LNAME` varchar(20) DEFAULT NULL,
  `HOME_STATE` varchar(20) DEFAULT NULL,
  `ZIP` varchar(20) DEFAULT NULL,
  `SCHLRSHP` int(11) DEFAULT NULL,
  PRIMARY KEY (`STU_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Student`
--

LOCK TABLES `Student` WRITE;
/*!40000 ALTER TABLE `Student` DISABLE KEYS */;
INSERT INTO `Student` VALUES (1,'John','White','MI','15642',1000),(2,'Davis','Brown','CA','52188',0),(3,'Wong','Tim','TX','75102',1500),(4,'Kerry','Osbourn','TX','77586',1500),(5,'Doug','Williams','TX','77586',500),(6,'Tim','Page','NY','10210',1000),(7,'Beth','Wooden','LA','36541',1500),(8,'Charlie','Pott','NM','48576',1500),(9,'Mike','Henderson','OK','65214',300),(10,'Bernard','Paterson','TX','73405',1500),(11,'Tim','Wilson','TX','77766',2000),(12,'Albert','Kennedy','TX','77766',1500),(13,'Diane','Page','AR','72120',400),(14,'Cheryl','Lee','TX','73130',1200);
/*!40000 ALTER TABLE `Student` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Studios`
--

DROP TABLE IF EXISTS `Studios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Studios` (
  `StudioID` int(11) NOT NULL,
  `StudioName` varchar(40) DEFAULT NULL,
  `Address` varchar(60) DEFAULT NULL,
  `City` varchar(25) DEFAULT NULL,
  `Region` varchar(15) DEFAULT NULL,
  `PostalCode` varchar(10) DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `WebAddress` varchar(40) DEFAULT NULL,
  `Contact` varchar(50) DEFAULT NULL,
  `EMail` varchar(40) DEFAULT NULL,
  `Phone` varchar(16) DEFAULT NULL,
  `SalesID` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`StudioID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Studios`
--

LOCK TABLES `Studios` WRITE;
/*!40000 ALTER TABLE `Studios` DISABLE KEYS */;
INSERT INTO `Studios` VALUES (1,'MakeTrax','3000 S St Rd 9','Anderson','IN','46012','USA','www.maketrax.com','Gardner Roberts','groberts@maketrax.com','7651223000',3),(2,'Lone Star Recording','PO Box 221','Davis','TX','76382','USA','www.lsrecords.com','Manuel Austin','ma@lonestarrec.com','8821993748',2),(3,'Pacific Rim','681 PCH','Santa Theresa','CA','99320','USA','www.pacrim.org','Harry Lee','harry@pcrim.org','3811110033',2);
/*!40000 ALTER TABLE `Studios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Titles`
--

DROP TABLE IF EXISTS `Titles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Titles` (
  `TitleID` int(11) NOT NULL,
  `ArtistID` int(11) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `StudioID` int(11) DEFAULT NULL,
  `UPC` varchar(13) DEFAULT NULL,
  `Genre` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`TitleID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Titles`
--

LOCK TABLES `Titles` WRITE;
/*!40000 ALTER TABLE `Titles` DISABLE KEYS */;
INSERT INTO `Titles` VALUES (1,1,'Meet the Neurotics',1,'2727366627','alternative'),(3,15,'Smell the Glove',2,'1283772282','metal'),(4,10,'Time Flies',3,'1882344222','alternative'),(5,1,'Neurotic Sequel',1,'2828830202','alternative'),(6,5,'Sonatas',2,'3999320021','classical'),(7,2,'Louis at the Keys',3,'3838227111','jazz');
/*!40000 ALTER TABLE `Titles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Tracks`
--

DROP TABLE IF EXISTS `Tracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Tracks` (
  `TitleID` int(11) NOT NULL,
  `TrackNum` smallint(6) NOT NULL,
  `TrackTitle` varchar(50) DEFAULT NULL,
  `LengthSeconds` smallint(6) DEFAULT NULL,
  `MP3` smallint(6) DEFAULT NULL,
  `RealAud` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`TitleID`,`TrackNum`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Tracks`
--

LOCK TABLES `Tracks` WRITE;
/*!40000 ALTER TABLE `Tracks` DISABLE KEYS */;
INSERT INTO `Tracks` VALUES (4,1,'Bob\'s Dream',185,1,1),(4,3,'Third\'s Folly',352,1,1),(4,2,'My Wizard',233,1,1),(3,1,'Fat Cheeks',352,1,1),(1,1,'Hottie',233,1,1),(1,2,'Goodtime March',293,1,1),(1,3,'TV Day',305,1,1),(1,4,'Call Me an Idiot',315,1,1),(1,5,'25',402,1,1),(1,6,'Palm',322,1,1),(1,7,'Front Door',192,1,1),(1,8,'Where\'s the Rain',175,1,1),(3,2,'Rocky and Natasha',283,1,1),(3,3,'Dweeb',273,1,1),(3,4,'Funky Town',252,1,1),(3,5,'Shoes',182,1,1),(3,6,'Time In - In Time',129,1,1),(6,1,'Violin Sonata No. 1 in D Major',511,1,1),(6,2,'Violin Sonata No. 2 in A Major',438,1,1),(6,3,'Violin Sonata No. 4 in E Minor',821,1,0),(6,4,'Piano Sonata No. 1',493,1,0),(6,5,'Clarinet Sonata in E Flat',399,1,0),(5,1,'Song 1',285,1,1),(5,2,'Song 2',272,1,1),(5,3,'Song 3',299,1,1),(5,4,'Song 4',201,1,1),(5,5,'Song 5',198,1,0),(5,6,'Song 6',254,1,0),(5,7,'Song 7',303,1,1),(5,8,'Song 8',230,1,0),(5,9,'Song 8 and 1/2',45,1,0),(7,1,'I Don\'t Know',201,1,0),(7,2,'What\'s the Day',332,1,0),(7,3,'Sirius',287,1,0),(7,4,'Hamburger Blues',292,1,0),(7,5,'Road Trip',314,1,0),(7,6,'Meeting You',321,1,1),(7,7,'Improv 34',441,1,1),(7,8,'Hey',288,1,1),(4,4,'Leather',185,1,1),(4,5,'Hot Cars Cool Nights',192,1,1),(4,6,'Music in You',204,1,1),(4,7,'Don\'t Care About Time',221,1,1),(4,8,'Kiss',218,1,1),(4,9,'Pizza Box',183,1,1),(4,10,'Goodbye',240,1,1),(3,7,'Wooden Man',314,0,0),(3,8,'UPS',97,0,0),(3,9,'Empty',182,0,0),(3,10,'Burrito',65,0,0);
/*!40000 ALTER TABLE `Tracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `Trucks`
--

DROP TABLE IF EXISTS `Trucks`;
/*!50001 DROP VIEW IF EXISTS `Trucks`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `Trucks` (
  `Color` tinyint NOT NULL,
  `Make` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `Vehicle`
--

DROP TABLE IF EXISTS `Vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Vehicle` (
  `VehicleID` int(11) NOT NULL AUTO_INCREMENT,
  `Color` varchar(30) NOT NULL,
  `Make` varchar(30) NOT NULL,
  `Model` varchar(30) NOT NULL,
  `CustomerID` int(11) NOT NULL,
  PRIMARY KEY (`VehicleID`),
  KEY `CustomerID` (`CustomerID`),
  CONSTRAINT `Vehicle_ibfk_1` FOREIGN KEY (`CustomerID`) REFERENCES `Customer` (`CustomerID`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Vehicle`
--

LOCK TABLES `Vehicle` WRITE;
/*!40000 ALTER TABLE `Vehicle` DISABLE KEYS */;
INSERT INTO `Vehicle` VALUES (1,'Blue','Good','Truck',3),(2,'Red','Bad','SUV',3),(3,'Red','Okay','Car',3),(4,'Green','Good','Motorcycle',3),(5,'Orange','Great','Truck',3),(6,'Grey','Ford','Truck',4);
/*!40000 ALTER TABLE `Vehicle` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Worker`
--

DROP TABLE IF EXISTS `Worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Worker` (
  `WorkerID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Specialty` varchar(30) NOT NULL,
  PRIMARY KEY (`WorkerID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Worker`
--

LOCK TABLES `Worker` WRITE;
/*!40000 ALTER TABLE `Worker` DISABLE KEYS */;
INSERT INTO `Worker` VALUES (1,'John Smith','Mechanic');
/*!40000 ALTER TABLE `Worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `XrefArtistsMembers`
--

DROP TABLE IF EXISTS `XrefArtistsMembers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `XrefArtistsMembers` (
  `MemberID` int(11) NOT NULL,
  `ArtistID` int(11) NOT NULL,
  `RespParty` smallint(6) NOT NULL,
  PRIMARY KEY (`MemberID`,`ArtistID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `XrefArtistsMembers`
--

LOCK TABLES `XrefArtistsMembers` WRITE;
/*!40000 ALTER TABLE `XrefArtistsMembers` DISABLE KEYS */;
INSERT INTO `XrefArtistsMembers` VALUES (20,2,1),(31,14,1),(3,1,1),(10,3,1),(13,3,0),(7,5,1),(8,5,0),(9,5,0),(32,15,0),(19,15,1),(21,15,0),(34,17,1),(29,17,0),(15,10,1),(35,10,0),(14,10,0),(33,16,1),(26,16,0),(18,18,1),(28,18,0),(22,18,0),(30,11,1),(36,11,0);
/*!40000 ALTER TABLE `XrefArtistsMembers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `child`
--

DROP TABLE IF EXISTS `child`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `child` (
  `cid` int(11) NOT NULL,
  `cname` varchar(20) DEFAULT NULL,
  `pid` int(11) DEFAULT NULL,
  PRIMARY KEY (`cid`),
  KEY `par_ind` (`pid`),
  CONSTRAINT `child_ibfk_1` FOREIGN KEY (`pid`) REFERENCES `parent` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `child`
--

LOCK TABLES `child` WRITE;
/*!40000 ALTER TABLE `child` DISABLE KEYS */;
INSERT INTO `child` VALUES (21,'Child One',2),(22,'Child Two',2),(23,'Fast Child',2);
/*!40000 ALTER TABLE `child` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dept`
--

DROP TABLE IF EXISTS `dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dept` (
  `dept_ID` int(11) NOT NULL,
  `dept_name` varchar(20) DEFAULT NULL,
  `num_emp` int(11) DEFAULT NULL,
  PRIMARY KEY (`dept_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dept`
--

LOCK TABLES `dept` WRITE;
/*!40000 ALTER TABLE `dept` DISABLE KEYS */;
INSERT INTO `dept` VALUES (1,'HeadQuarter',1),(2,'Accounting',3),(3,'HR',1);
/*!40000 ALTER TABLE `dept` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(20) DEFAULT NULL,
  `dept_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `dept_ID` (`dept_ID`),
  CONSTRAINT `employee_ibfk_1` FOREIGN KEY (`dept_ID`) REFERENCES `dept` (`dept_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (51,'Amy',1),(52,'Parker',2),(53,'Sam',2),(54,'Jordan',2),(55,'Taylor',3);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`4040510_database`@`%`*/ /*!50003 TRIGGER `after_insert_emp` AFTER INSERT ON `employee`
 FOR EACH ROW  
 	UPDATE dept SET num_emp = 
 			(SELECT COUNT(*) FROM employee WHERE employee.dept_ID = NEW.dept_ID) 
 	WHERE dept.dept_ID = NEW.dept_ID */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `parent`
--

DROP TABLE IF EXISTS `parent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `parent` (
  `id` int(11) NOT NULL,
  `fullname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parent`
--

LOCK TABLES `parent` WRITE;
/*!40000 ALTER TABLE `parent` DISABLE KEYS */;
INSERT INTO `parent` VALUES (2,'Sam Commerce');
/*!40000 ALTER TABLE `parent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblContracts`
--

DROP TABLE IF EXISTS `tblContracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblContracts` (
  `ArtistID` int(11) NOT NULL,
  `ContractDate` date NOT NULL,
  PRIMARY KEY (`ArtistID`,`ContractDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblContracts`
--

LOCK TABLES `tblContracts` WRITE;
/*!40000 ALTER TABLE `tblContracts` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblContracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tblX`
--

DROP TABLE IF EXISTS `tblX`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tblX` (
  `ID` int(11) NOT NULL,
  `anotherfield` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tblX`
--

LOCK TABLES `tblX` WRITE;
/*!40000 ALTER TABLE `tblX` DISABLE KEYS */;
/*!40000 ALTER TABLE `tblX` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `testTable`
--

DROP TABLE IF EXISTS `testTable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `testTable` (
  `ID` smallint(6) NOT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Address` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `testTable`
--

LOCK TABLES `testTable` WRITE;
/*!40000 ALTER TABLE `testTable` DISABLE KEYS */;
INSERT INTO `testTable` VALUES (102,'Amy Yellow','507 Main Street Dallas TX 75000');
/*!40000 ALTER TABLE `testTable` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `vwArtistWebs`
--

DROP TABLE IF EXISTS `vwArtistWebs`;
/*!50001 DROP VIEW IF EXISTS `vwArtistWebs`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `vwArtistWebs` (
  `Artistname` tinyint NOT NULL,
  `Webaddress` tinyint NOT NULL,
  `Leadsource` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Dumping routines for database '4040510_database'
--

--
-- Final view structure for view `Trucks`
--

/*!50001 DROP TABLE IF EXISTS `Trucks`*/;
/*!50001 DROP VIEW IF EXISTS `Trucks`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`4040510_database`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `Trucks` AS select `Vehicle`.`Color` AS `Color`,`Vehicle`.`Make` AS `Make` from `Vehicle` where (`Vehicle`.`Model` = 'Truck') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `vwArtistWebs`
--

/*!50001 DROP TABLE IF EXISTS `vwArtistWebs`*/;
/*!50001 DROP VIEW IF EXISTS `vwArtistWebs`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`4040510_database`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `vwArtistWebs` AS select `Artists`.`ArtistName` AS `Artistname`,`Artists`.`WebAddress` AS `Webaddress`,`Artists`.`LeadSource` AS `Leadsource` from `Artists` where (`Artists`.`WebAddress` is not null) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-11-12  4:31:47
